'use strict'

module.exports = function noNext (app, opts, next) {
  // no call to next
}
