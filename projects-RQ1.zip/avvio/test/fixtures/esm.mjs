export default async function (app) {
  app.loaded = true
}
