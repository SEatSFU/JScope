"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const avvio = __importStar(require("../../"));
{
    // avvio with no argument
    const app = avvio();
    app.override = (server, fn, options) => server;
    app.use((server, opts, done) => {
        server.use;
        server.after;
        server.ready;
        server.on;
        server.start;
        server.override;
        server.onClose;
        server.close;
        opts.mySuper;
        done();
    }, { mySuper: "option" });
    app.use(async (server, options) => {
        server.use;
        server.after;
        server.ready;
        server.on;
        server.start;
        server.override;
        server.onClose;
        server.close;
    });
    app.after(err => {
        if (err)
            throw err;
    });
    app.after((err, done) => {
        done();
    });
    app.after((err, context, done) => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
        done();
    });
    app.ready().then(context => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
    });
    app.ready(err => {
        if (err)
            throw err;
    });
    app.ready((err, done) => {
        done();
    });
    app.ready((err, context, done) => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
        done();
    });
    app.close(err => {
        if (err)
            throw err;
    });
    app.close((err, done) => {
        done();
    });
    app.close((err, context, done) => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
        done();
    });
    app.onClose((context, done) => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
        done();
    });
}
{
    // avvio with done
    const app = avvio(() => undefined);
    app.use((server, opts, done) => {
        server.use;
        server.after;
        server.ready;
        server.on;
        server.start;
        server.override;
        server.onClose;
        server.close;
        opts.mySuper;
        done();
    }, { mySuper: "option" });
    app.use(async (server, options) => {
        server.use;
        server.after;
        server.ready;
        server.on;
        server.start;
        server.override;
        server.onClose;
        server.close;
    });
    app.after(err => {
        if (err)
            throw err;
    });
    app.after((err, done) => {
        done();
    });
    app.after((err, context, done) => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
        done();
    });
    app.ready().then(context => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
    });
    app.ready(err => {
        if (err)
            throw err;
    });
    app.ready((err, done) => {
        done();
    });
    app.ready((err, context, done) => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
        done();
    });
    app.close(err => {
        if (err)
            throw err;
    });
    app.close((err, done) => {
        done();
    });
    app.close((err, context, done) => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
        done();
    });
    app.onClose((context, done) => {
        context.use;
        context.after;
        context.ready;
        context.on;
        context.start;
        context.override;
        context.onClose;
        context.close;
        done();
    });
}
{
    const server = { typescriptIs: "amazing" };
    // avvio with server
    const app = avvio(server);
    app.use((server, opts, done) => {
        server.use;
        server.after;
        server.ready;
        server.typescriptIs;
        opts.mySuper;
        done();
    }, { mySuper: "option" });
    app.use(async (server, options) => {
        server.use;
        server.after;
        server.ready;
        server.typescriptIs;
    });
    app.after(err => {
        if (err)
            throw err;
    });
    app.after((err, done) => {
        done();
    });
    app.after((err, context, done) => {
        context.use;
        context.after;
        context.ready;
        context.typescriptIs;
        done();
    });
    app.ready().then(context => {
        context.use;
        context.after;
        context.ready;
        context.typescriptIs;
    });
    app.ready(err => {
        if (err)
            throw err;
    });
    app.ready((err, done) => {
        done();
    });
    app.ready((err, context, done) => {
        context.use;
        context.after;
        context.ready;
        context.close;
        context.onClose;
        context.typescriptIs;
        done();
    });
    app.close(err => {
        if (err)
            throw err;
    });
    app.close((err, done) => {
        done();
    });
    app.close((err, context, done) => {
        context.use;
        context.after;
        context.ready;
        context.close;
        context.onClose;
        context.typescriptIs;
        done();
    });
    app.onClose((context, done) => {
        context.use;
        context.after;
        context.ready;
        context.close;
        context.onClose;
        context.typescriptIs;
        done();
    });
}
{
    const server = { hello: "world" };
    const options = {
        autostart: false,
        expose: { after: "after", ready: "ready", use: "use" }
    };
    // avvio with server and options
    const app = avvio(server, options);
}
{
    const server = { hello: "world" };
    const options = {
        autostart: false,
        expose: { after: "after", ready: "ready", use: "use" }
    };
    // avvio with server, options and done callback
    const app = avvio(server, options, () => undefined);
}
{
    const app = avvio();
    const plugin = async () => { };
    const promise = plugin(app, {}, undefined);
    (promise instanceof Promise);
}
//# sourceMappingURL=index.js.map