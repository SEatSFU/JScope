'use strict'

module.exports = {
  rules: {
    strict: 'error',
    'no-shadow': 0, // XXX: fix this later
  },
}
