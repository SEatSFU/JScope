# Styles

todo

## Semantic styles

todo

## .style

The `prompt.style()` method returns the style to use based on the current prompt [status](state.md#status).
