# Text Prompt

See [Input prompt](input.md).
