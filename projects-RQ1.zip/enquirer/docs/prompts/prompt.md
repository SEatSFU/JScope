# Prompt

- [ ] Timers
- [ ] Refreshing prompts to create loaders or spinners with custom logic (without timers)
- [ ] Skipping prompts
- [ ] Custom render method
