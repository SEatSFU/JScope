# Form Prompt

**Todo**

- [ ] Custom pointer
- [ ] Custom symbols
- [ ] Hint
- [ ] ~~History / completion~~ (coming soon!)
- [ ] Field validation
- [ ] Required fields
- [ ] Default values
- [ ] Resetting
