# Input Prompt

**Todo**

- [ ] Custom pointer
- [ ] Custom symbols
- [ ] Hint
- [ ] History / completion
