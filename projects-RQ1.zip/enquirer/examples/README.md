# Examples

This folder contains _examples for using all of Enquirer's prompts_.  See the [recipes](../recipes) to see recipes for creating custom prompts.
