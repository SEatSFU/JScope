# Recipes

This folder contains _recipes for creating custom prompts_. See the [examples](../examples) directory for extensive prompt usage examples.
