require('time-require');
console.time('enquirer');
require('..');
console.timeEnd('enquirer');
// enquirer: 4.169ms
// enquirer: 3.936ms
// enquirer: 3.933ms
// avg: 4.013ms
