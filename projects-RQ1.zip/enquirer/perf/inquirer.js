require('time-require');
console.time('inquirer');
require('inquirer');
console.timeEnd('inquirer');
// inquirer: 312.322ms (first run)
// inquirer: 279.338ms (second run)
// inquirer: 268.492ms (third run)
// avg: 286.717
