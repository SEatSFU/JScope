# Prompts

Built-in prompts:

- [autocomplete](#autocomplete)
- [confirm](#confirm)
- [input](#input)
- [invisible](#invisible)
- [list](#list)
- [multiselect](#multiselect)
- [number](#number)
- [password](#password)
- [select](#select)
