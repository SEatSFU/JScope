# HEADS UP!

For the latest markdown docs, go to the [docs](../docs) folder instead. 

Currently, this folder contains outdated documentation for Enquirer v1.0, as well as the build system for the website. We'll revisit this after the [docs](../docs) are updated for Enquirer v2.0. 
