"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const Enquirer = __importStar(require("../.."));
new Enquirer();
new Enquirer.Prompt();
new Enquirer.Prompt({ name: 'test', type: 'text', message: '' });
Enquirer
    .prompt({ name: 'test', type: 'text', message: '' })
    .then(answer => answer);
Enquirer
    .prompt(() => ({ name: 'test', type: 'text', message: '' }))
    .then(answer => answer);
Enquirer
    .prompt([
    { name: 'test', type: 'text', message: '' },
    () => ({ name: 'test', type: 'text', message: '' })
])
    .then(answer => answer);
Enquirer
    .prompt({ name: 'question', type: 'text', message: '' })
    .then(answer => answer.question);
const instance = new Enquirer({}, { question1: '' });
instance
    .register('custom1', Enquirer.Prompt)
    .register('custom2', () => Enquirer.Prompt)
    .register({
    custom1: Enquirer.Prompt,
    custom2: () => Enquirer.Prompt
});
instance
    .prompt({ name: 'test', type: 'text', message: '' })
    .then(answer => answer.question1);
instance
    .prompt(() => ({ name: 'test', type: 'text', message: '' }))
    .then(answer => answer.question1);
instance
    .prompt([
    { name: 'test', type: 'text', message: '' },
    () => ({ name: 'test', type: 'text', message: '' })
])
    .then(answer => answer.question1);
instance
    .use(function () {
    this.register('', Enquirer.Prompt);
})
    .use(enquirer => {
    enquirer.register('', Enquirer.Prompt);
});
class CustomPrompt extends Enquirer.Prompt {
    render() { }
}
const customPrompt = new CustomPrompt();
customPrompt.run().then(answer => answer);
// Prompt options
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    required: true
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    format() {
        return '';
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    async format() {
        return '';
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    format(value) {
        return value;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    result() {
        return '';
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    async result() {
        return '';
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    result(value) {
        return value;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    skip: true
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    async skip() {
        return true;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    skip(state) {
        return !!state;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    validate() {
        return true;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    async validate() {
        return true;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    validate(value) {
        return value;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    async validate(value) {
        return value;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    onSubmit(name, value, prompt) {
        return true;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    async onSubmit(name, value, prompt) {
        return true;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    onCancel(name, value, prompt) {
        return true;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    async onCancel(name, value, prompt) {
        return true;
    }
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    stdin: process.stdin
});
Enquirer.prompt({
    name: 'test',
    type: 'text',
    message: '',
    stdout: process.stdout
});
//# sourceMappingURL=test.js.map