'use strict';

module.exports = require('./out');
